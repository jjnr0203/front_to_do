import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PageMuseumRoutingModule } from './page-museum-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PageMuseumRoutingModule
  ]
})
export class PageMuseumModule { }
